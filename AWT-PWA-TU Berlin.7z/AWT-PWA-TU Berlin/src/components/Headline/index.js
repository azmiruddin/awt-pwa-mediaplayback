import { MainHeadline } from './MainHeadline';
import { SecondaryHeadline } from './SecondaryHeadline';

export { MainHeadline, SecondaryHeadline };
