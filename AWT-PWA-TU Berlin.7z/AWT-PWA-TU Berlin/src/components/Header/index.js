import { Header } from './ResponsiveHeader';

export default Header;
