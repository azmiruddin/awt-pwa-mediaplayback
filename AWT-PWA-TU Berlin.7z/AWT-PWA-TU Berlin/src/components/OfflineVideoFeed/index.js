import { OfflineVideoFeed } from './OfflineVideoFeed';

export default OfflineVideoFeed;
