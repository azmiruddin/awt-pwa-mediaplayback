import React from 'react';

export const Footer = () => {

    // <!-- prs footer Wrapper Start -->
  return  <div>
	
	<div class="prs_bottom_footer_wrapper">	<a href="javascript:" id="return-to-top"><i class="flaticon-play-button"></i></a>
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-8 col-xs-12" style={{textAlign:"center"}}>
					<div class="prs_bottom_footer_cont_wrapper">
						<p>Copyright 2019-20 <a href="#">Progressive Web App</a> . All rights reserved
						</p>
					</div>
				</div>
				<div class="col-lg-6 col-md-6 col-sm-4 col-xs-12">
					{/* <div class="prs_footer_social_wrapper">
						<ul>
							<li><a href="#"><i class="fa fa-facebook"></i></a>
							</li>
							<li><a href="#"><i class="fa fa-twitter"></i></a>
							</li>
							<li><a href="#"><i class="fa fa-linkedin"></i></a>
							</li>
							<li><a href="#"><i class="fa fa-youtube-play"></i></a>
							</li>
						</ul>
					</div> */}
				</div>
			</div>
		</div>
	</div>
	{/* <!-- prs footer Wrapper End --> */}
    </div>

}
{/* <div>copy right @ Eng-Qutibah</div>; */}

export default Footer;
