import { ShakaPlayer } from './ShakaPlayer';

export default ShakaPlayer;
