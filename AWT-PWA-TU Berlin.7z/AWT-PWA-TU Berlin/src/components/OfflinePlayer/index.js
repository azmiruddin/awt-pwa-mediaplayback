import { OfflinePlayer } from './OfflinePlayer';
import { withRouter } from 'react-router-dom';

export default withRouter(OfflinePlayer);
